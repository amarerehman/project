/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_book;

/**
 *
 * @author ESHOP
 */
public class book {
    String title;
    String author;
    String regno;
    boolean isAvailable;

    // Constructor to initialize the book
    public book(String title, String author, String regno, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.regno = regno;
        this.isAvailable = isAvailable;
    }

    // Getters and setters (optional but good practice)
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getregno() {
        return regno;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
public void setauthor(String author) {
        this.author=author;
    }
   
public void setregno(String regno) {
        this.regno=regno;
    }
public void settitle(String title) {
        this.title=title;
    }
}
