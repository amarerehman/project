/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_book;
import java.util.LinkedList;
/**
 *
 * @author ESHOP
 */
public class user {
     private String username;
    private String password;
    private String cnic;
    private LinkedList<book> lendBooks;  // List of books borrowed by the user
    
    // No-argument constructor
    public user() {
        this.username = "";
        this.password = "";
        this.cnic = "";
        this.lendBooks = new LinkedList<>();
    }


    // Constructor
    public user(String username, String password, String cnic) {
        this.username = username;
        this.password = password;
        this.cnic=cnic;
        this.lendBooks = new LinkedList<>();
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Method to borrow a book
    public void lendBook(book book) {
        lendBooks.add(book);
    }

    // Method to return a book
    public void returnBook(book book) {
        lendBooks.remove(book);
    }

    // Method to get the list of borrowed books
    public LinkedList<book> getlendedBooks() {
        return lendBooks;
    }

    // Method to check if the user has borrowed a specific book
    public boolean haslended(book book) {
        return lendBooks.contains(book);
    }

    public String getcnic() {
        return username;
    }

    LinkedList<book> getlendBooks() {
      return lendBooks;
    }
}
