/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_book;

/**
 *
 * @author ESHOP
 */
import java.util.LinkedList;
public class ebook_system {
    private String adminUsername = "ebook";  // Admin username (hardcoded for simplicity)
   private String adminPassword = "123";  // Admin password (hardcoded for simplicity)

   private LinkedList<book> books;  // List of all books in the library
   private LinkedList<user> users;  // List of all users in the library

   public ebook_system() {
       this.books = new LinkedList<>();
       this.users = new LinkedList<>();
   }

   // Method to add a new book to the library
   public void addBook(book newBook) {
       books.add(newBook);
   }

   // Method to remove a book from the library by title
   public void removeBook(book book) {
       books.remove(book);
   }

   // Method to find a book by its title
   public book findBookByTitle(String title) {
       for (book book : books) {
           if (book.getTitle().equalsIgnoreCase(title)) {
               return book;
           }
       }
       return null;
   }

/// Method to remove a book by its ID
   public void removeBookByID(int bookID) {
       if (bookID >= 0 && bookID < books.size()) {
           books.remove(bookID);
       }
   }

   // Method to borrow a book by a user
   public boolean lendBook(user user, String title) {
       if (user == null) { 
           System.out.println("User is not set. Cannot lend book."); 
           return false;
       }
       book book = findBookByTitle(title); 
       if (book != null && book.isAvailable()) { 
           book.setAvailable(false); 
           user.lendBook(book); 
           return true;
       } 
       return false;
   }

   // Method to return a book by a user
   public boolean returnBook(user user, String title) {
       book book = findBookByTitle(title);
       if (book != null && !book.isAvailable()) {
           book.setAvailable(true);  // Mark the book as available
           user.returnBook(book);    // Remove the book from the user's borrowed list
           return true;
       }
       return false;  // Return false if the book is not borrowed or not found
   }

   // Method to add a user to the system
   public boolean addUser(String username, String password, String cnic) {
       // Check if the username already exists
       if (findUserByUsername(username) != null) {
           return false;  // Username already exists
       }
       
       // Add the new user if the username is unique
       user newUser = new user(username, password, cnic);
       users.add(newUser);
       return true;
   }

   // Method to remove a user from the system
   

   // Method to find a user by their username
   public user findUserByUsername(String username) {
       for (user user : users) {
           if (user.getUsername().equalsIgnoreCase(username)) {
               return user;
           }
       }
       return null;
   }

   // Method to get a list of all books in the library
   public LinkedList<book> getAllBooks() {
       return books;
   }

   // Method to get a list of all users in the system
   public LinkedList<user> getAllUsers() {
       return users;
   }

   // Method to check admin login
   public boolean adminLogin(String username, String password) {
       return username.equals(adminUsername) && password.equals(adminPassword);
   }

   // Method to verify user login
   public boolean verifyUserLogin(String username, String password) {
       user u = findUserByUsername(username);
       return u != null && u.getPassword().equals(password);
   }

   // Method to search for books in the library by title, author, or ISBN
   public LinkedList<book> searchBooks(String query) {
       LinkedList<book> result = new LinkedList<>();
       for (book b : books) {
           if (b.getTitle().contains(query) || b.getAuthor().contains(query) || b.getregno().contains(query)) {
               result.add(b);
           }
       }
       return result;
   }

   // Method to update book availability (used in Admin Dashboard)
   public void updateBookAvailability(int bookID, boolean availability) {
       if (bookID >= 0 && bookID < books.size()) {
           books.get(bookID).setAvailable(availability);
       }
   }

   // Method to get the list of borrowed books
   public LinkedList<book> getlendBooks() {
       LinkedList<book> lendBooks = new LinkedList<>();
       for (book b : books) {
           if (!b.isAvailable()) {
               lendBooks.add(b);
           }
       }
       return lendBooks;
   }

   // Method to get a user's borrowed books
   public LinkedList<book> getUselendBooks(user u) {
       return u.getlendBooks();
   }
   // Method to update book details (title, author, or ISBN)
   public boolean updateBook(int bookID, String newTitle, String newAuthor, String newregno) {
       if (bookID >= 0 && bookID < books.size()) {
           book b = books.get(bookID);
           // Update book details
           b.settitle(newTitle);
           b.setauthor(newAuthor);
           b.setregno(newregno);
           return true;  // Book details successfully updated
       }
       return false;  // Book not found
   }

    boolean AdminLogin(String enteredUsername, String enteredPassword) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
